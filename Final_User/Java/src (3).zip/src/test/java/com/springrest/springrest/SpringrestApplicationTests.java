package com.springrest.springrest;

import org.junit.jupiter.api.Test;


@SpringBootTest
class SpringrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
