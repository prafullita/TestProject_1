package com.springrest.springrest.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springrest.springrest.entities.Enquiry;


public interface EnquiryDao extends JpaRepository<Enquiry,Integer>{

}
