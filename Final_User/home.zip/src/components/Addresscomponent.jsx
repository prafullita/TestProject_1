function Addresscomponent(){
    return (
<div className="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                
                                <div className="">
                                    <br/>
                                    <h1 className="title"><span>Reach us at</span></h1>
                                    <div className="sub-title">
                                        <p><strong>Vidyanidhi Infotech Academy</strong><br/>
                                            5th Floor, Vidyanidhi Education
                                            Complex, Vidyanidhi Road, Juhu
                                            Scheme Andheri (W), Mumbai 400 049
                                            India</p>
                                       
                                        <p><strong>Mobile :</strong> 9029435311
                                            / 9324095272 / 9987062416</p>
                                        <p><strong>Email : </strong><a
                                                href="mailto:training@vidyanidhi.com">training@vidyanidhi.com</a></p>
                                    </div>
                                </div>

                            </div>
    );
}
export default Addresscomponent;