import React from 'react';
//import {Jumbotron} from 'react-bootstrap';

function Home()
{
    return(
    <div>            
   
                <h1>Courses</h1>
                <p> Hello this our component</p>
            
            </div>
    )
    
};

export default Home;