const base_url = "http://localhost:8082";
export default base_url;